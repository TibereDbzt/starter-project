import '../styles/main.scss';

import { mousePos } from 'utils/getters';

const init = () => {
    // make things like this
    console.log('Mouse X : ' + mousePos.x + ' | Mouse Y : ' + mousePos.y);
};

window.addEventListener('load', () => {
    init();
});
